import React, { forwardRef } from 'react'

function Tab1() {
    return (
        <div>
            Tab1
        </div>
    )
}

export default Tab1
