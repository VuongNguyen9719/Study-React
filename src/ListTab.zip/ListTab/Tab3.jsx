import React, { forwardRef } from 'react'

function Tab3() {
    return (
        <div>
            Tab3
        </div>
    )
}


export default Tab3